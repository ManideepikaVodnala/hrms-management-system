 const express = require('express');
const path = require('path');
const cors = require('cors');
const connection = require('./db');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

// Serve bonus form page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'bonus.html'));
});

// Submit bonus request
app.post('/api/bonus', (req, res) => {
  const { employee_id, employee_name, department, type, amount, reason } = req.body;

  const query = `
    INSERT INTO bonus_requests (employee_id, employee_name, department, type, amount, reason)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  const values = [employee_id, employee_name, department, type, amount, reason];

  connection.query(query, values, (err, result) => {
    if (err) {
      console.error('Insert error:', err);
      return res.status(500).send('Database insert error');
    }
    res.send('Bonus request submitted successfully!');
  });
});

// Get all bonus requests
app.get('/api/bonus', (req, res) => {
  connection.query('SELECT * FROM bonus_requests', (err, results) => {
    if (err) {
      console.error('Fetch error:', err);
      return res.status(500).send('Database fetch error');
    }
    res.json(results);
  });
});

app.listen(3001, () => {
  console.log('Bonus server running at http://localhost:3001');
});
