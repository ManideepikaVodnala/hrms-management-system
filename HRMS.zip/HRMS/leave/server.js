 const express = require('express');
const path = require('path');
const connection = require('./db');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

// Serve HTML files
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'leave.html'));
});

app.get('/HRLEAVEREQUEST.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'HRLEAVEREQUEST.html'));
});

// Insert leave request
app.post('/api/leaves', (req, res) => {
  const { empId, name, department, email,  startDate, endDate, reason } = req.body;

const query = `
  INSERT INTO leave_requests (employeeId, employeeName, department, email, startDate, endDate, reason, status)
  VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')
`;

const values = [empId, name, department, email, startDate, endDate, reason || 'N/A'];


  connection.query(query, values, (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      return res.status(500).send('Database error');
    }
    res.send('Success! Your leave request has been submitted.');
  });
});

// Fetch leave requests
app.get('/api/leaves', (req, res) => {
  connection.query('SELECT * FROM leave_requests', (err, results) => {
    if (err) {
      console.error('Fetch error:', err);
      return res.status(500).send('Error fetching data');
    }
    res.json(results);
  });
});

// Update status
app.put('/api/leaves/:id', (req, res) => {
  const { id } = req.params; // This is the employeeId
  const { status } = req.body;

  connection.query(
    'UPDATE leave_requests SET status = ? WHERE employeeId = ?',
    [status, id],
    (err, result) => {
      if (err) {
        console.error('Update error:', err);
        return res.status(500).send('Error updating status');
      }

      if (result.affectedRows === 0) {
        return res.status(404).send('No matching employeeId found');
      }

      res.send('Status updated successfully');
    }
  );
});

app.listen(3006, () => {
  console.log('Server running at http://localhost:3006');
});