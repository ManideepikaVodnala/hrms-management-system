const express = require('express');
const cors = require('cors');
const fileUpload = require('express-fileupload');
const path = require('path');
const fs = require('fs');
const db = require('./db');

const app = express();
const PORT = 3010;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(fileUpload());

// Serve static files from the root folder (where claim.html and admin.html are)
app.use(express.static(__dirname));

// Ensure 'uploads' folder exists
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// Default route
app.get('/', (req, res) => {
  res.send('Claim Backend is running!');
});

// Serve claim.html at /claim
app.get('/claim', (req, res) => {
  res.sendFile(path.join(__dirname, 'claim.html'));
});

// Serve admin.html at /admin
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

// API: Submit a new claim
app.post('/api/submit-claim', (req, res) => {
  const {
    fullName,
    employeeCode,
    department,
    claimType,
    policyNumber,
    medicalCondition,
    incidentDate,
    claimAmount,
    description
  } = req.body;

  let documentName = '';

  if (req.files && req.files.document) {
    const doc = req.files.document;
    documentName = `${Date.now()}_${doc.name}`;
    const uploadPath = path.join(uploadDir, documentName);

    doc.mv(uploadPath, (err) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to upload document.' });
      }
    });
  }

  const sql = `
    INSERT INTO claims (
      fullName, employeeCode, department, claimType,
      policyNumber, medicalCondition, incidentDate,
      claimAmount, description, document
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const values = [
    fullName,
    employeeCode,
    department,
    claimType,
    policyNumber || null,
    medicalCondition || null,
    incidentDate,
    claimAmount,
    description,
    documentName
  ];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error('Database insert error:', err);
      return res.status(500).json({ error: 'Failed to submit claim.' });
    }
    res.status(200).json({ message: 'Claim submitted successfully.', id: result.insertId });
  });
});

// API: Get all claims
app.get('/api/get-all-claims', (req, res) => {
  const sql = 'SELECT * FROM claims ORDER BY submissionDate DESC';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Database fetch error:', err);
      return res.status(500).json({ error: 'Failed to fetch claims.' });
    }
    res.status(200).json(results);
  });
});

// API: Update claim status
app.put('/api/update-claim-status/:id', (req, res) => {
  const claimId = req.params.id;
  const { status } = req.body;

  const sql = 'UPDATE claims SET status = ? WHERE id = ?';
  db.query(sql, [status, claimId], (err, result) => {
    if (err) {
      console.error('Database update error:', err);
      return res.status(500).json({ error: 'Failed to update status.' });
    }
    res.status(200).json({ message: 'Claim status updated successfully.' });
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Server running at: http://localhost:${PORT}`);
});
