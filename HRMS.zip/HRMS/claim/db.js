  const mysql = require('mysql2');
 
 const connection = mysql.createConnection({
   host: 'localhost',
   user: 'root',
   password: 'Deepika@0503', // use your actual MySQL root password
   database: 'ats_claim'     // make sure this database exists
 });
 
 connection.connect((err) => {
   if (err) {
     console.error('Connection error:', err);
   } else {
     console.log('Connected to MySQL (Claim DB)');
   }
 });
 
 module.exports = connection;