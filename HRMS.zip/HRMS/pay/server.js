const express = require('express');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db');

const app = express();
const PORT = 3020;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname))); // Serve payemp.html and paysliphr.html

// Save payslip to DB
app.post('/api/payslip', (req, res) => {
    const data = req.body;

    const sql = `
        REPLACE INTO payslips (
            employee_code, employee_name, employee_type, designation, date_of_joining,
            days_in_month, working_days, arrear_days, lop, office_location,
            bank_name, bank_account_no, pan_no, provident_fund, uan_no, esic_no,
            payslip_month, payslip_year,
            basic, hra, education_allowance, bonus, other_allowance, gross_pay,
            professional_tax, labour_welfare, epf, ppf, total_deductions,
            net_pay, net_pay_words
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
        data.employeeCode, data.employeeName, data.employeeType, data.designation, data.dateOfJoining,
        data.daysInMonth, data.workingDays, data.arrearDays, data.lop, data.officeLocation,
        data.bankName, data.bankAccountNo, data.panNo, data.providentFund, data.uanNo, data.esicNo,
        data.month, data.year,
        data.earnings.basic, data.earnings.hra, data.earnings.educationAllowance,
        data.earnings.bonus, data.earnings.otherAllowance, data.earnings.grossPay,
        data.deductions.professionalTax, data.deductions.labourWelfare, data.deductions.epf,
        data.deductions.ppf, data.deductions.totalDeductions,
        data.netPay, data.netPayWords
    ];

    db.query(sql, values, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Payslip saved successfully!' });
    });
});

// Fetch payslip from DB
app.get('/api/payslip', (req, res) => {
    const { employeeCode, month, year } = req.query;

    const sql = `
        SELECT * FROM payslips
        WHERE employee_code = ? AND payslip_month = ? AND payslip_year = ?
    `;

    db.query(sql, [employeeCode, month, year], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Payslip not found' });
        res.json(results[0]);
    });
});

app.listen(PORT, () => {
    console.log(`✅ Server running at http://localhost:${PORT}`);
});
