// backend/db.js
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Deepika@0503', // 🔁 PUT your actual MySQL root password here
    database: 'payslip_system'
});

connection.connect((err) => {
    if (err) throw err;
    console.log('MySQL Connected!');
});

module.exports = connection;
