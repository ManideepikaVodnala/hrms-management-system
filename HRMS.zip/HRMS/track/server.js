const express = require('express');
const path = require('path');
const cors = require('cors');
const connection = require('./db'); // MySQL connection

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

// Serve HR form page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'track.html'));
});

// Insert HR form data
app.post('/api/track', (req, res) => {
  const {
    employee_id,
    employee_name,
    Current_Designation,
    New_Designation,
    Old_salary,
    New_salary,
    Promotion_Date,
    Promotion_Basis,
    Increment,
    Bonus
  } = req.body;

  console.log('Track request received:', req.body);

  const query = `
    INSERT INTO track_requests (
      employee_id, employee_name, Current_Designation, New_Designation,
      Old_salary, New_salary, Promotion_Date, Promotion_Basis, Increment, Bonus
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const values = [
    employee_id,
    employee_name,
    Current_Designation,
    New_Designation,
    Old_salary,
    New_salary,
    Promotion_Date,
    Promotion_Basis,
    Increment,
    Bonus
  ];

  connection.query(query, values, (err, result) => {
    if (err) {
      console.error('Insert error:', err);
      return res.status(500).send('Database insert error');
    }
    res.send('Track request submitted successfully!');
  });
});

// Get all requests (admin or HR view)
app.get('/api/track', (req, res) => {
  connection.query('SELECT * FROM track_requests', (err, results) => {
    if (err) {
      console.error('Fetch error:', err);
      return res.status(500).send('Database fetch error');
    }
    res.json(results);
  });
});

// ✅ Get employee-specific record by ID and Name
app.get('/api/track/:id/:name', (req, res) => {
  const { id, name } = req.params;
  const query = `
    SELECT * FROM track_requests
    WHERE employee_id = ? AND employee_name = ?
  `;

  connection.query(query, [id, name], (err, results) => {
    if (err) {
      console.error('Error fetching employee data:', err);
      return res.status(500).send('Database error');
    }
    res.json(results);
  });
});

// Start server
const PORT = 3003;
app.listen(PORT, () => {
  console.log(`Track server running at http://localhost:${PORT}`);
});

