const express = require('express');
const path = require('path');
const connection = require('./db');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

// Serve HTML files
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'offboarding.html'));
});

app.get('/hroffboarding.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'hroffboarding.html'));
});

// ✅ Insert new offboarding request
app.post('/api/offboarding', (req, res) => {
  console.log("Received data:", req.body); // Debug log

  const {
    empId,
    name,
    department,
    email,
    lastWorkingDate,
    reason,
    projectName,
    projectRole,
    projectStatus,
    projectDescription,
    assetsAssigned,
    assetReturnStatus,
    feedback
  } = req.body;

  const query = `
    INSERT INTO offboarding_requests 
    (empId, name, department, email, lastWorkingDay, reasonForExit, projectName, projectRole, projectStatus, briefProjectDescription, companyAssetsAssigned, assetReturnStatus, feedbackOrComments, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
  `;

  const values = [
    empId, name, department, email, lastWorkingDate, reason, projectName, projectRole,
    projectStatus, projectDescription, assetsAssigned, assetReturnStatus, feedback
  ];

  connection.query(query, values, (err, result) => {
    if (err) {
      console.error('Error inserting data:', err); // Debug log
      return res.status(500).send('Database error');
    }
    res.send('Success! Your offboarding request has been submitted.');
  });
});

// ✅ Fetch all offboarding requests
app.get('/api/assets', (req, res) => {
  connection.query('SELECT * FROM offboarding_requests', (err, results) => {
    if (err) {
      console.error('Fetch error:', err);
      return res.status(500).send('Error fetching data');
    }
    res.json(results);
  });
});

// ✅ Update offboarding request status (Approve/Reject)
app.put('/api/offboarding/:id', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const query = 'UPDATE offboarding_requests SET status = ? WHERE id = ?';
  const values = [status, id];

  connection.query(query, values, (err, result) => {
    if (err) {
      console.error('Error updating status:', err.sqlMessage);
      return res.status(500).send('Failed to update status');
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Request not found');
    }
    res.send('Status updated successfully');
  });
});

// ✅ Start the server
app.listen(3004, () => {
  console.log('🚀 Server running at http://localhost:3004');
});

