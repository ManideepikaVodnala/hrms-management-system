require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3033; // Using your port 3033

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, './')));

// API Routes
app.post('/api/appraisals', async (req, res) => {
  try {
    const {
      employeeName,
      employeeId,
      appraiserName,
      appraiserRole,
      qualityOfWork,
      productivity,
      teamCollaboration,
      initiative,
      strengths,
      areasForImprovement,
      additionalComments,
      hrComments,
      approvalCheckbox
    } = req.body;

    // Validate required fields
    if (!employeeName || !employeeId || !appraiserName || !appraiserRole) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const query = `
      INSERT INTO appraisals (
        employee_name, 
        employee_id, 
        appraiser_name, 
        appraiser_role,
        quality_of_work,
        productivity,
        team_collaboration,
        initiative,
        strengths,
        areas_for_improvement,
        additional_comments,
        hr_comments,
        is_approved,
        created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `;

    const result = await db.query(query, [
      employeeName,
      employeeId,
      appraiserName,
      appraiserRole,
      qualityOfWork,
      productivity,
      teamCollaboration,
      initiative,
      strengths,
      areasForImprovement,
      additionalComments,
      hrComments || null,
      approvalCheckbox || false
    ]);

    res.status(201).json({ 
      message: 'Appraisal submitted successfully',
      id: result.insertId
    });
  } catch (error) {
    console.error('Error submitting appraisal:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/appraisals', async (req, res) => {
  try {
    const { employeeId, employeeName } = req.query;
    
    if (!employeeId || !employeeName) {
      return res.status(400).json({ error: 'Employee ID and Name are required' });
    }

    const query = `
      SELECT * FROM appraisals 
      WHERE employee_id = ? 
      AND LOWER(employee_name) = LOWER(?)
      ORDER BY created_at DESC
    `;

    const appraisals = await db.query(query, [employeeId, employeeName]);
    
    if (appraisals.length === 0) {
      return res.status(404).json({ error: 'No appraisals found for this employee' });
    }

    res.json(appraisals);
  } catch (error) {
    console.error('Error fetching appraisals:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Serve HTML files
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'appraisal.html'));
});

app.get('/employee-view', (req, res) => {
  res.sendFile(path.join(__dirname, 'emp.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});