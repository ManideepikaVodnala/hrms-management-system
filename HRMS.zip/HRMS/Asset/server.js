const express = require('express');
const path = require('path');
const connection = require('./db');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

// Serve HTML files
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'Asset', 'asset.html'));

});

app.get('/hrasset.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'Asset', 'hrasset.html'));

});

// Insert asset request
app.post('/api/assets', (req, res) => {
  const { empId, name, department, email, assetType, requiredDate, deviceIssue } = req.body;
  const query = `
    INSERT INTO asset_requests (empId, name, department, email, assetType, requiredDate, deviceIssue, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')
  `;
  const values = [empId, name, department, email, assetType, requiredDate, deviceIssue || 'N/A'];

  connection.query(query, values, (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      return res.status(500).send('Database error');
    }
    res.send('Success! Your asset request has been submitted.');
  });
});

// Fetch asset requests
app.get('/api/assets', (req, res) => {
  connection.query('SELECT * FROM asset_requests', (err, results) => {
    if (err) {
      console.error('Fetch error:', err);
      return res.status(500).send('Error fetching data');
    }
    res.json(results);
  });
});

// Update status
app.put('/api/assets/:id', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  connection.query('UPDATE asset_requests SET status = ? WHERE id = ?', [status, id], (err, result) => {
    if (err) {
      console.error('Update error:', err);
      return res.status(500).send('Error updating status');
    }
    res.send('Status updated successfully');
  });
});

app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});



