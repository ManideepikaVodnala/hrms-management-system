// attendanceServer.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const connection = require('./db_attendance');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'attendance.html'));
});

// Punch In API
app.post('/api/punch-in', (req, res) => {
  const { employeeId, date, inTime } = req.body;

  const query = `
    INSERT INTO attendance_records (employeeId, date, punchIn)
    VALUES (?, ?, ?)
  `;
  connection.query(query, [employeeId, date, inTime], (err, result) => {
    if (err) {
      console.error('Punch In error:', err);
      return res.status(500).send('Database error during Punch In');
    }
    res.send('Punch In recorded');
  });
});

// Punch Out API
app.put('/api/punch-out', (req, res) => {
  const { employeeId, date, outTime, hours } = req.body;

  const query = `
    UPDATE attendance_records
    SET punchOut = ?, hours = ?
    WHERE employeeId = ? AND date = ?
  `;
  connection.query(query, [outTime, hours, employeeId, date], (err, result) => {
    if (err) {
      console.error('Punch Out error:', err);
      return res.status(500).send('Database error during Punch Out');
    }
    res.send('Punch Out recorded');
  });
});

// Fetch attendance records
app.get('/api/attendance', (req, res) => {
  connection.query('SELECT * FROM attendance_records', (err, results) => {
    if (err) {
      console.error('Fetch error:', err);
      return res.status(500).send('Error fetching records');
    }
    res.json(results);
  });
});

// Start the server
app.listen(3005, () => {
  console.log('✅ Attendance server running at http://localhost:3005');
});
